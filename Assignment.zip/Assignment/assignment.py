import pandas as pd
import numpy as np
import requests
from dotenv import load_dotenv
import os
# Load environment variables from .env file
load_dotenv()


#loading the environment variables
# basic_url = os.getenv("basic_url")
api_url = os.getenv("basic_url")+os.getenv("latitude")+"&"+os.getenv("longitude")+"&appid="+os.getenv("api")

def fetch_weather_data(url=api_url):
    """
    Fetches weather data for a given lan and log from OpenWeatherMap.
    """
    try:
        response = requests.get(url)
        # Check if the request was successful        
        if response.status_code == 200:
            print("Data fetched successfully")
            # Parse the JSON response
            return response.json()
        else:
            print(f"Error fetching data: {response.status_code}")
            return None
    # Handle any exceptions that occur during the request
    # such as network issues or invalid URLs
    except requests.RequestException as e:
        print(f"Error fetching data: {e}")
        return None
    
def parse_weather_data(data):
    """
    Extracts temperature and weather condition from the API response.
    """
    try:
        # Extracting data from the JSON response
        temp = data['main']['temp'] - 273.15  # Convert from Kelvin to Celsius
        temp = round(temp, 2)  # Round to 2 decimal places
        log = data['coord']['lon']
        lat = data['coord']['lat']
        weather = data['weather'][0]['description']
        city = data['name']
        return city, temp, weather, log, lat
    # Handle any exceptions that occur during data extraction
    # such as missing keys or incorrect data types
    except (KeyError, TypeError):
        print("Error parsing data.")
        return None
    
    
    
def display_weather_info(city, temp, condition, log, lat):
    """
    Displays the weather information in a clean format.
    """
    # Displaying the weather information
    print(f"\nWeather in {city}:")
    print(f"Temperature: {temp}°C")
    print(f"Condition : {condition.capitalize()}")
    print(f"Longitude : {log}")
    print(f"Latitude : {lat}")
    
    
if __name__ == "__main__":
    # Example usage
    data = fetch_weather_data()
    # Check if data is not None before parsing
    # and displaying the weather information
    if data:
        parsed = parse_weather_data(data)
        # Check if parsed data is not None before displaying
        # the weather information
        if parsed:
            display_weather_info(*parsed)
    

    