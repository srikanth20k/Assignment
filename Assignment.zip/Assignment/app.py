from flask import Flask, render_template, request
from Assignment.assignment  import fetch_weather_data, parse_weather_data, display_weather_info



app = Flask(__name__)

@app.route("/home")
def home():
    """
    Renders the home page of the web application.
    """
    return "this is the home page"

@app.route("/", methods=["GET"])
def index():
    """
    Handles the main page of the web application."""
    data = fetch_weather_data()
    # Check if data is not None before parsing
    # and displaying the weather information
    if data:
        parsed = parse_weather_data(data)
        # Check if parsed data is not None before displaying
        # the weather information
        if parsed:
            display_weather_info(*parsed)
    return render_template("index.html", data=parsed,city=data['name'], temp=data['main']['temp']- 273.15, condition=data['weather'][0]['description'],
                            latitude=data['coord']['lat'],longitude=data['coord']['lon'],)
    


if __name__ == "__main__":
    app.run(debug=True)
   