

-- creating new data base-- 
create database assignment; 

--  creating the table with given fields -- 
create table orders_ass(
order_id int,
customer_id int,
ordered_date  date, 
amount float
);

-- This are the given data --
-- 1 101 2023-01-01 250.00--
-- 2 102 2023-01-02 150.00-- 
-- 3 101 2023-01-05 100.00
-- 4 103 2023-01-07 300.00

 -- insering the given data into the  above created table -- 
insert into orders_ass(order_id,customer_id,ordered_date,amount) values(1,101,'2023-01-01',250.0),
(2,102,'2023-01-02',150.0),
(3, 101,'2023-01-05' ,100.00),
(4,103, '2023-01-07', 300.00);

select * from orders_ass;

----------- given queries to answers-----------
-- Write SQL queries for the following:
-- a) Get the total amount spent by each customer.
-- b) List all orders placed after '2023-01-03'.
-- c) Get the customer(s) who made more than one order.

-- a) Get the total amount spent by each customer

select customer_id,sum(amount) as total_amount -- sum the amount and group by the customer_id to get each spend  by the customer--
from orders_ass
group by customer_id
order by total_amount;

-- b) List all orders placed after '2023-01-03'.
select *
from orders_ass
where ordered_date > '2023-01-03';

-- c) Get the customer(s) who made more than one order.
select customer_id,count(1) as total_orders   -- count the customers and group it where customer with more then 1 order are displayed --
from orders_ass
group by customer_id
having total_orders >1;




